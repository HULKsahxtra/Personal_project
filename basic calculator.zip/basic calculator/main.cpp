#include <iostream>

using namespace std;

// Function declarations
float add(float x, float y) {
    return x + y;
}

float subtract(float x, float y) {
    return x - y;
}

float multiply(float x, float y) {
    return x * y;
}

float divide(float x, float y) {
    if (y != 0) {
        return x / y;
    } else {
        cout << "Error: Division by zero" << endl;
        return 0;  // Returning 0 as an indication of the error
    }
}

int main() {
    char choice;
    float num1, num2;

    do {
        // Display menu
        cout << "Select operation:" << endl;
        cout << "1. Add" << endl;
        cout << "2. Subtract" << endl;
        cout << "3. Multiply" << endl;
        cout << "4. Divide" << endl;
        cout << "5. Exit" << endl;

        // Take user choice
        cout << "Enter choice (1/2/3/4/5): ";
        cin >> choice;

        if (choice == '5') {
            cout << "Exiting the calculator." << endl;
            break;
        }

        if (choice < '1' || choice > '4') {
            cout << "Invalid input. Please enter a valid choice." << endl;
            continue;
        }

        // Take user input for numbers
        cout << "Enter first number: ";
        cin >> num1;
        cout << "Enter second number: ";
        cin >> num2;

        // Perform the selected operation
        switch (choice) {
            case '1':
                cout << "Result: " << add(num1, num2) << endl;
                break;
            case '2':
                cout << "Result: " << subtract(num1, num2) << endl;
                break;
            case '3':
                cout << "Result: " << multiply(num1, num2) << endl;
                break;
            case '4':
                cout << "Result: " << divide(num1, num2) << endl;
                break;
        }

    } while (true);

    return 0;
}
